import React, { useState, useMemo } from "react";

const DATA = {"games":[["2025-10-21","Oklahoma City Thunder","Houston Rockets",-250,205,6.5,225.5,249,1,0.685,0.6,0.3,10,10],["2025-10-21","Los Angeles Lakers","Golden State Warriors",130,-154,-2.5,227.5,228,0,0.418,0.4,0.4,10,10],["2025-10-22","Milwaukee Bucks","Washington Wizards",-620,400,11.5,230.5,253,1,0.812,0.6,0.2,10,10],["2025-10-22","New York Knicks","Cleveland Cavaliers",104,-122,-1.5,229.5,230,1,0.471,0.4,0.5,10,10],["2025-10-22","Orlando Magic","Miami Heat",-350,280,8.5,216.5,246,1,0.747,0.5,0.4,10,10],["2025-10-22","Charlotte Hornets","Brooklyn Nets",-200,168,5.5,228.5,253,1,0.641,0.1,0.3,10,10],["2025-10-22","Atlanta Hawks","Toronto Raptors",-210,176,5.5,237.5,256,0,0.652,0.4,0.5,10,10],["2025-10-22","Boston Celtics","Philadelphia 76ers",-198,166,5.5,230.5,233,0,0.639,0.5,0.1,10,10],["2025-10-22","Chicago Bulls","Detroit Pistons",138,-164,-3.5,236.5,226,1,0.403,0.6,0.3,10,10],["2025-10-22","Utah Jazz","LA Clippers",255,-350,-9.5,225.5,237,1,0.266,0.1,0.6,10,10],["2025-10-22","Dallas Mavericks","San Antonio Spurs",-168,142,3.5,224.5,217,0,0.603,0.4,0.3,10,10],["2025-10-22","Phoenix Suns","Sacramento Kings",-176,148,4.0,228.5,236,1,0.613,0.1,0.4,10,10],["2025-10-22","Portland Trail Blazers","Minnesota Timberwolves",162,-190,-5.0,222.5,232,0,0.368,0.4,0.5,10,10],["2025-10-22","Memphis Grizzlies","New Orleans Pelicans",-178,150,4.0,236.5,250,1,0.615,0.3,0.2,10,10],["2025-10-23","Golden State Warriors","Denver Nuggets",-108,-108,1.0,232.5,268,1,0.5,0.4,0.5,2,10],["2025-10-23","Indiana Pacers","Oklahoma City Thunder",230,-310,-7.5,229.5,276,0,0.286,0.5,0.7,10,2],["2025-10-24","New York Knicks","Boston Celtics",-176,148,4.0,231.5,200,1,0.613,0.5,0.4,2,2],["2025-10-24","Houston Rockets","Detroit Pistons",-290,215,6.5,224.5,226,0,0.701,0.3,0.3,3,2],["2025-10-24","Toronto Raptors","Milwaukee Bucks",-132,112,2.0,235.5,238,0,0.547,0.5,0.6,2,2],["2025-10-24","Orlando Magic","Atlanta Hawks",-225,188,6.0,235.5,218,0,0.666,0.5,0.4,2,2],["2025-10-24","Brooklyn Nets","Cleveland Cavaliers",480,-650,-11.5,230.5,255,0,0.166,0.3,0.5,2,2],["2025-10-24","New Orleans Pelicans","San Antonio Spurs",150,-178,-4.0,233.5,236,0,0.385,0.1,0.4,2,2],["2025-10-24","Dallas Mavericks","Washington Wizards",-420,330,9.5,228.5,224,0,0.776,0.3,0.2,2,2],["2025-10-24","Portland Trail Blazers","Golden State Warriors",154,-200,-4.5,227.5,258,1,0.371,0.4,0.4,2,1],["2025-10-24","Sacramento Kings","Utah Jazz",-162,126,2.5,235.5,209,1,0.583,0.4,0.2,2,2],["2025-10-24","LA Clippers","Phoenix Suns",-430,340,10.0,223.5,231,1,0.781,0.5,0.2,2,2],["2025-10-24","Los Angeles Lakers","Minnesota Timberwolves",108,-126,-1.5,225.5,238,1,0.463,0.3,0.6,3,2],["2025-10-24","Memphis Grizzlies","Miami Heat",-156,132,3.0,232.5,260,0,0.586,0.3,0.3,2,2],["2025-10-25","Philadelphia 76ers","Charlotte Hornets",-200,166,5.0,236.5,246,1,0.639,0.2,0.2,3,3],["2025-10-25","Atlanta Hawks","Oklahoma City Thunder",280,-390,-8.5,234.5,217,0,0.248,0.5,0.7,1,2],["2025-10-25","Orlando Magic","Chicago Bulls",-240,198,6.5,232.5,208,0,0.678,0.4,0.7,1,3],["2025-10-25","Denver Nuggets","Phoenix Suns",-750,460,13.5,232.5,244,1,0.832,0.4,0.2,2,1],["2025-10-25","Memphis Grizzlies","Indiana Pacers",-140,110,2.0,240.5,231,1,0.551,0.3,0.4,1,2],["2025-10-26","Sacramento Kings","Los Angeles Lakers",-138,108,1.5,224.5,247,0,0.547,0.5,0.4,2,2],["2025-10-26","San Antonio Spurs","Brooklyn Nets",-500,385,10.5,227.5,225,1,0.802,0.5,0.3,2,2],["2025-10-26","Cleveland Cavaliers","Milwaukee Bucks",-260,215,6.5,233.5,231,1,0.695,0.5,0.6,2,2],["2025-10-26","Detroit Pistons","Boston Celtics",-140,110,2.5,227.5,232,1,0.551,0.3,0.4,2,2],["2025-10-26","Dallas Mavericks","Toronto Raptors",-106,-110,-1.0,231.5,268,1,0.496,0.3,0.4,2,2],["2025-10-26","Minnesota Timberwolves","Indiana Pacers",-510,390,11.5,228.5,224,1,0.804,0.5,0.4,2,1],["2025-10-26","LA Clippers","Portland Trail Blazers",-335,275,8.5,224.5,221,1,0.743,0.5,0.5,2,2],["2025-10-26","Miami Heat","New York Knicks",140,-168,-3.5,230.5,222,1,0.399,0.4,0.5,2,2],["2025-10-26","Washington Wizards","Charlotte Hornets",-120,102,1.5,240.5,252,0,0.524,0.3,0.2,2,1],["2025-10-27","Chicago Bulls","Atlanta Hawks",118,-138,-2.5,244.5,251,1,0.442,0.8,0.5,2,2],["2025-10-27","Minnesota Timberwolves","Denver Nuggets",194,-235,-6.5,229.5,241,0,0.327,0.5,0.5,1,2],["2025-10-27","Utah Jazz","Phoenix Suns",-120,102,1.5,230.5,272,1,0.524,0.2,0.2,3,2],["2025-10-27","Golden State Warriors","Memphis Grizzlies",-335,275,8.5,240.5,249,1,0.743,0.4,0.4,3,2],["2025-10-27","Dallas Mavericks","Oklahoma City Thunder",300,-375,-9.0,224.5,195,0,0.241,0.3,0.7,1,2],["2025-10-27","San Antonio Spurs","Toronto Raptors",-178,150,4.5,232.5,224,1,0.615,0.6,0.3,1,1],["2025-10-27","Detroit Pistons","Cleveland Cavaliers",110,-130,-2.0,231.5,211,0,0.457,0.4,0.5,1,1],["2025-10-27","New Orleans Pelicans","Boston Celtics",154,-184,-4.5,231.5,212,0,0.378,0.1,0.3,3,1],["2025-10-27","Houston Rockets","Brooklyn Nets",-1150,730,16.0,224.5,246,1,0.884,0.3,0.2,3,1],["2025-10-27","Philadelphia 76ers","Orlando Magic",188,-225,-6.5,227.5,260,1,0.334,0.3,0.3,2,2],["2025-10-27","Los Angeles Lakers","Portland Trail Blazers",136,-174,-3.5,221.5,230,0,0.4,0.4,0.5,1,1],["2025-10-28","Washington Wizards","Philadelphia 76ers",148,-176,-4.5,239.5,273,0,0.387,0.3,0.4,2,1],["2025-10-28","Miami Heat","Charlotte Hornets",-150,118,2.5,239.5,261,1,0.567,0.4,0.2,2,2],["2025-10-28","Milwaukee Bucks","New York Knicks",114,-134,-2.0,228.5,232,1,0.449,0.5,0.5,2,2],["2025-10-28","Oklahoma City Thunder","Sacramento Kings",-390,310,9.0,227.5,208,1,0.765,0.8,0.5,1,2],["2025-10-28","Golden State Warriors","LA Clippers",-156,122,2.5,225.5,177,1,0.575,0.5,0.5,1,2],["2025-10-29","Denver Nuggets","New Orleans Pelicans",-590,440,11.5,237.5,210,1,0.822,0.5,0.0,2,2],["2025-10-29","Minnesota Timberwolves","Los Angeles Lakers",-620,400,11.5,230.5,231,0,0.812,0.4,0.3,2,2],["2025-10-29","Utah Jazz","Portland Trail Blazers",128,-152,-3.0,235.5,270,0,0.421,0.3,0.5,2,2],["2025-10-29","Phoenix Suns","Memphis Grizzlies",110,-130,-2.5,242.5,227,0,0.457,0.2,0.3,2,2],["2025-10-29","Dallas Mavericks","Indiana Pacers",-240,182,4.5,224.5,212,1,0.666,0.3,0.3,2,3],["2025-10-29","Brooklyn Nets","Atlanta Hawks",275,-340,-8.5,239.5,229,0,0.257,0.1,0.4,2,2],["2025-10-29","Chicago Bulls","Sacramento Kings",-196,152,4.5,238.5,239,1,0.625,0.8,0.4,2,1],["2025-10-29","Toronto Raptors","Houston Rockets",210,-280,-5.5,233.5,260,0,0.304,0.3,0.4,2,2],["2025-10-29","Detroit Pistons","Orlando Magic",190,-250,-6.5,229.5,251,1,0.326,0.4,0.3,2,2],["2025-10-29","Boston Celtics","Cleveland Cavaliers",130,-166,-3.5,233.5,230,1,0.411,0.3,0.5,2,2],["2025-10-30","Oklahoma City Thunder","Washington Wizards",-1150,730,15.5,230.5,235,1,0.884,0.8,0.2,2,2],["2025-10-30","Charlotte Hornets","Orlando Magic",134,-158,-3.5,238.5,230,0,0.411,0.2,0.2,2,1],["2025-10-30","San Antonio Spurs","Miami Heat",-215,164,7.5,234.5,208,1,0.643,0.6,0.5,3,2],["2025-10-30","Milwaukee Bucks","Golden State Warriors",240,-295,-7.5,228.5,230,1,0.283,0.5,0.5,2,2],["2025-10-31","LA Clippers","New Orleans Pelicans",-550,410,11.0,223.5,250,1,0.812,0.5,0.0,3,2],["2025-10-31","Phoenix Suns","Utah Jazz",-210,162,6.5,231.5,214,1,0.64,0.2,0.3,2,2],["2025-10-31","Portland Trail Blazers","Denver Nuggets",190,-230,-5.5,240.5,216,1,0.331,0.5,0.5,2,2],["2025-10-31","Memphis Grizzlies","Los Angeles Lakers",100,-128,-1.5,236.5,229,0,0.471,0.4,0.4,2,2],["2025-10-31","Cleveland Cavaliers","Toronto Raptors",-184,154,4.0,237.5,213,0,0.622,0.4,0.3,2,2],["2025-10-31","Indiana Pacers","Atlanta Hawks",114,-134,-2.5,232.5,236,0,0.449,0.2,0.5,2,2],["2025-10-31","Philadelphia 76ers","Boston Celtics",122,-156,-1.5,231.5,217,0,0.425,0.5,0.4,3,2],["2025-10-31","Chicago Bulls","New York Knicks",162,-194,-5.0,233.5,260,1,0.366,0.8,0.4,2,3],["2025-11-01","Detroit Pistons","Dallas Mavericks",-270,220,7.0,228.5,232,1,0.7,0.5,0.4,3,3],["2025-11-01","Boston Celtics","Houston Rockets",168,-200,-5.0,226.5,229,0,0.359,0.5,0.5,1,3],["2025-11-01","Indiana Pacers","Golden State Warriors",390,-590,-10.5,233.5,223,1,0.193,0.2,0.4,1,2],["2025-11-01","Charlotte Hornets","Minnesota Timberwolves",156,-186,-4.5,235.5,227,0,0.375,0.2,0.3,2,3],["2025-11-01","Washington Wizards","Orlando Magic",295,-370,-9.0,233.5,219,0,0.243,0.2,0.3,2,2],["2025-11-01","Milwaukee Bucks","Sacramento Kings",-250,205,6.5,232.5,268,0,0.685,0.5,0.3,2,3],["2025-11-02","Cleveland Cavaliers","Atlanta Hawks",-245,200,6.5,230.5,226,1,0.681,0.4,0.5,2,2],["2025-11-02","Charlotte Hornets","Utah Jazz",108,-126,-1.5,232.5,229,1,0.463,0.2,0.3,1,2],["2025-11-02","Oklahoma City Thunder","New Orleans Pelicans",-650,420,12.5,236.5,243,1,0.818,0.9,0.0,3,2],["2025-11-02","Toronto Raptors","Memphis Grizzlies",-194,150,4.5,237.5,221,1,0.623,0.4,0.3,2,2],["2025-11-02","Brooklyn Nets","Philadelphia 76ers",136,-174,-4.5,234.5,234,0,0.4,0.1,0.5,4,2],["2025-11-02","Los Angeles Lakers","Miami Heat",-295,215,8.5,237.5,250,1,0.702,0.5,0.4,2,3],["2025-11-02","New York Knicks","Chicago Bulls",-310,230,8.5,231.5,244,1,0.714,0.4,0.8,2,2],["2025-11-02","Phoenix Suns","San Antonio Spurs",190,-230,-5.0,227.5,248,1,0.331,0.3,0.7,2,3],["2025-11-03","Memphis Grizzlies","Detroit Pistons",146,-174,-4.0,235.5,220,0,0.39,0.3,0.5,1,2],["2025-11-03","Houston Rockets","Dallas Mavericks",-720,520,12.5,226.5,212,1,0.845,0.5,0.4,2,2],["2025-11-03","Portland Trail Blazers","Los Angeles Lakers",-390,310,10.5,227.5,238,0,0.765,0.6,0.5,3,1],["2025-11-03","Denver Nuggets","Sacramento Kings",-620,460,11.5,237.5,254,1,0.828,0.5,0.3,3,2],["2025-11-03","New York Knicks","Washington Wizards",-720,530,13.0,234.5,221,1,0.847,0.5,0.2,1,2],["2025-11-03","Boston Celtics","Utah Jazz",-1800,800,16.5,225.5,208,0,0.895,0.4,0.3,2,1],["2025-11-03","Indiana Pacers","Milwaukee Bucks",200,-245,-6.0,235.5,232,0,0.319,0.2,0.5,2,2],["2025-11-03","Brooklyn Nets","Minnesota Timberwolves",230,-310,-7.5,225.5,234,0,0.286,0.1,0.4,1,2],["2025-11-03","LA Clippers","Miami Heat",-146,114,3.5,229.5,239,0,0.559,0.5,0.3,3,1],["2025-11-04","Toronto Raptors","Milwaukee Bucks",-154,120,2.5,238.5,228,1,0.572,0.4,0.6,2,1],["2025-11-04","New Orleans Pelicans","Charlotte Hornets",-184,142,3.5,226.5,228,1,0.611,0.0,0.3,2,2],["2025-11-04","Atlanta Hawks","Orlando Magic",138,-164,-3.5,228.5,239,1,0.403,0.4,0.4,2,3],["2025-11-04","Chicago Bulls","Philadelphia 76ers",-134,114,2.0,240.5,224,1,0.551,0.8,0.6,2,2],["2025-11-04","Golden State Warriors","Phoenix Suns",-490,380,11.0,235.5,225,1,0.799,0.4,0.4,3,2],["2025-11-04","LA Clippers","Oklahoma City Thunder",270,-335,-8.5,219.5,233,0,0.26,0.4,0.9,1,2],["2025-11-05","Boston Celtics","Washington Wizards",-720,450,13.5,231.5,243,1,0.828,0.4,0.2,2,2],["2025-11-05","Denver Nuggets","Miami Heat",-375,300,9.0,241.5,234,1,0.759,0.5,0.4,2,2],["2025-11-05","Sacramento Kings","Golden State Warriors",-144,122,2.5,225.5,237,1,0.567,0.3,0.5,2,1],["2025-11-05","Portland Trail Blazers","Oklahoma City Thunder",124,-158,-3.5,229.5,240,1,0.422,0.5,0.9,2,1],["2025-11-05","Dallas Mavericks","New Orleans Pelicans",-310,250,8.0,225.5,200,0,0.726,0.3,0.1,2,1],["2025-11-05","Los Angeles Lakers","San Antonio Spurs",100,-118,-1.5,228.5,234,1,0.48,0.6,0.7,2,3],["2025-11-05","Cleveland Cavaliers","Philadelphia 76ers",-2500,900,16.5,235.5,253,1,0.906,0.5,0.6,3,1],["2025-11-05","Detroit Pistons","Utah Jazz",-420,330,10.0,233.5,217,1,0.776,0.6,0.4,2,2],["2025-11-05","Memphis Grizzlies","Houston Rockets",320,-460,-9.5,230.5,233,0,0.225,0.3,0.6,2,2],["2025-11-05","Indiana Pacers","Brooklyn Nets",-210,162,6.5,230.5,215,0,0.64,0.2,0.0,2,2],["2025-11-05","New York Knicks","Minnesota Timberwolves",-164,138,3.5,228.5,251,1,0.597,0.5,0.5,2,2],["2025-11-06","Phoenix Suns","LA Clippers",-156,122,2.5,224.5,217,1,0.575,0.4,0.4,2,2],["2025-11-07","Atlanta Hawks","Toronto Raptors",-215,164,4.5,232.5,206,0,0.643,0.4,0.4,3,3],["2025-11-07","San Antonio Spurs","Houston Rockets",196,-260,-5.5,223.5,231,1,0.319,0.7,0.7,2,2],["2025-11-07","Sacramento Kings","Oklahoma City Thunder",440,-590,-11.5,234.5,233,0,0.178,0.4,0.9,2,2],["2025-11-07","Minnesota Timberwolves","Utah Jazz",-620,460,12.5,233.5,234,1,0.828,0.4,0.3,2,2],["2025-11-07","Miami Heat","Charlotte Hornets",-245,200,7.5,235.5,234,1,0.681,0.4,0.3,2,3],["2025-11-07","Denver Nuggets","Golden State Warriors",-400,285,9.5,230.5,233,1,0.755,0.6,0.5,2,2],["2025-11-07","Brooklyn Nets","Detroit Pistons",265,-370,-10.5,230.5,232,0,0.258,0.1,0.7,2,2],["2025-11-07","Washington Wizards","Cleveland Cavaliers",800,-1800,-17.5,241.5,263,0,0.105,0.2,0.5,2,2],["2025-11-07","Orlando Magic","Boston Celtics",-164,138,3.5,226.5,233,1,0.597,0.3,0.4,3,2],["2025-11-07","Memphis Grizzlies","Dallas Mavericks",-180,152,4.5,232.5,222,1,0.618,0.3,0.3,2,2],["2025-11-07","Milwaukee Bucks","Chicago Bulls",-178,150,4.5,240.5,236,1,0.615,0.5,0.8,3,3],["2025-11-08","LA Clippers","Phoenix Suns",-192,148,4.5,226.5,217,0,0.62,0.4,0.4,2,2],["2025-11-08","Denver Nuggets","Indiana Pacers",-390,280,9.5,233.5,217,1,0.752,0.7,0.2,1,3],["2025-11-08","Miami Heat","Portland Trail Blazers",138,-178,-3.5,239.5,267,1,0.396,0.5,0.6,1,3],["2025-11-08","San Antonio Spurs","New Orleans Pelicans",-590,390,11.5,219.5,245,1,0.807,0.7,0.2,1,3],["2025-11-08","Washington Wizards","Dallas Mavericks",152,-180,-4.5,233.5,216,0,0.382,0.2,0.2,1,1],["2025-11-08","Cleveland Cavaliers","Chicago Bulls",-370,295,8.5,239.5,250,1,0.757,0.6,0.7,1,1],["2025-11-08","Atlanta Hawks","Los Angeles Lakers",144,-186,-4.5,228.5,224,1,0.387,0.4,0.7,1,3],["2025-11-08","Philadelphia 76ers","Toronto Raptors",-205,158,5.5,237.5,250,1,0.634,0.5,0.5,3,1],["2025-11-09","Milwaukee Bucks","Houston Rockets",134,-172,-3.5,231.5,237,0,0.403,0.6,0.6,2,2],["2025-11-09","New York Knicks","Brooklyn Nets",-1400,680,15.5,222.5,232,1,0.879,0.6,0.1,4,2],["2025-11-09","Memphis Grizzlies","Oklahoma City Thunder",320,-460,-10.5,234.5,214,0,0.225,0.4,0.9,2,2],["2025-11-09","Orlando Magic","Boston Celtics",-164,138,3.5,227.5,218,0,0.597,0.4,0.4,2,2],["2025-11-09","Philadelphia 76ers","Detroit Pistons",166,-198,-4.5,233.5,219,0,0.361,0.6,0.7,1,2],["2025-11-09","Golden State Warriors","Indiana Pacers",-620,460,12.5,220.5,197,1,0.828,0.5,0.1,2,1],["2025-11-09","Sacramento Kings","Minnesota Timberwolves",164,-196,-4.5,237.5,261,0,0.364,0.3,0.5,2,2],["2025-11-10","Detroit Pistons","Washington Wizards",-360,260,7.5,234.5,272,1,0.738,0.8,0.1,1,2],["2025-11-10","Phoenix Suns","New Orleans Pelicans",-360,260,7.5,223.5,219,1,0.738,0.5,0.2,2,2],["2025-11-10","Utah Jazz","Minnesota Timberwolves",210,-280,-7.5,232.5,233,0,0.304,0.3,0.6,3,1],["2025-11-10","Dallas Mavericks","Milwaukee Bucks",138,-164,-3.5,228.5,230,0,0.403,0.3,0.6,2,1],["2025-11-10","LA Clippers","Atlanta Hawks",-180,150,4.5,221.5,207,0,0.616,0.3,0.5,2,2],["2025-11-10","Miami Heat","Cleveland Cavaliers",290,-410,-9.5,238.5,278,1,0.242,0.6,0.7,2,2],["2025-11-10","Charlotte Hornets","Los Angeles Lakers",270,-335,-8.5,230.5,232,0,0.26,0.3,0.7,3,2],["2025-11-10","Orlando Magic","Portland Trail Blazers",-120,102,2.0,234.5,227,1,0.524,0.4,0.6,1,2],["2025-11-10","Chicago Bulls","San Antonio Spurs",168,-200,-5.0,235.5,238,0,0.359,0.6,0.8,2,2],["2025-11-11","New York Knicks","Memphis Grizzlies",-460,320,10.5,238.5,253,1,0.775,0.6,0.3,2,2],["2025-11-11","Brooklyn Nets","Toronto Raptors",220,-295,-7.5,231.5,228,0,0.295,0.1,0.5,2,3],["2025-11-11","Oklahoma City Thunder","Golden State Warriors",-350,280,8.0,228.5,228,1,0.747,0.9,0.5,2,2],["2025-11-11","Philadelphia 76ers","Boston Celtics",102,-130,-1.5,230.5,202,1,0.467,0.6,0.5,2,2],["2025-11-11","Sacramento Kings","Denver Nuggets",240,-330,-8.5,243.5,230,0,0.277,0.3,0.7,2,3],["2025-11-11","Utah Jazz","Indiana Pacers",230,-310,-7.5,243.5,280,1,0.286,0.3,0.1,1,2],["2025-11-12","Dallas Mavericks","Phoenix Suns",-132,104,1.5,227.5,237,0,0.537,0.3,0.5,2,2],["2025-11-12","LA Clippers","Denver Nuggets",152,-196,-4.5,221.5,246,0,0.375,0.3,0.8,2,1],["2025-11-12","Sacramento Kings","Atlanta Hawks",144,-172,-4.0,229.5,233,0,0.393,0.3,0.6,1,2],["2025-11-12","Oklahoma City Thunder","Los Angeles Lakers",-360,260,8.5,228.5,213,1,0.738,0.9,0.8,1,2],["2025-11-12","Houston Rockets","Washington Wizards",-2000,1040,17.0,237.5,247,1,0.916,0.6,0.1,3,2],["2025-11-12","San Antonio Spurs","Golden State Warriors",-168,142,3.5,232.5,245,0,0.603,0.8,0.4,2,1],["2025-11-12","Miami Heat","Cleveland Cavaliers",-370,265,7.5,247.5,246,0,0.742,0.7,0.7,2,2],["2025-11-12","Boston Celtics","Memphis Grizzlies",-500,340,10.5,224.5,226,1,0.786,0.5,0.3,1,1],["2025-11-12","Detroit Pistons","Chicago Bulls",130,-154,-3.0,229.5,237,1,0.418,0.9,0.6,2,2],["2025-11-12","New York Knicks","Orlando Magic",-178,150,4.0,227.5,231,0,0.615,0.7,0.4,1,2],["2025-11-12","New Orleans Pelicans","Portland Trail Blazers",275,-340,-8.5,232.5,242,0,0.257,0.2,0.5,2,2],["2025-11-12","Charlotte Hornets","Milwaukee Bucks",120,-142,-2.5,228.5,211,1,0.437,0.3,0.6,2,2],["2025-11-13","Cleveland Cavaliers","Toronto Raptors",-290,215,7.5,236.5,239,0,0.701,0.7,0.5,1,2],["2025-11-13","Phoenix Suns","Indiana Pacers",-178,148,4.0,232.5,231,1,0.614,0.6,0.1,1,2],["2025-11-13","Utah Jazz","Atlanta Hawks",104,-132,-1.5,234.5,254,0,0.463,0.3,0.6,2,1],["2025-11-14","Milwaukee Bucks","Charlotte Hornets",-430,300,11.5,232.5,281,1,0.764,0.5,0.3,2,2],["2025-11-14","Dallas Mavericks","LA Clippers",136,-162,-3.0,220.5,260,0,0.407,0.3,0.3,2,2],["2025-11-14","New Orleans Pelicans","Los Angeles Lakers",350,-450,-9.5,227.5,222,0,0.214,0.2,0.7,2,2],["2025-11-14","New York Knicks","Miami Heat",-255,210,6.5,240.5,272,1,0.69,0.6,0.6,2,2],["2025-11-14","Minnesota Timberwolves","Sacramento Kings",-500,340,11.5,237.5,234,1,0.786,0.6,0.2,4,2],["2025-11-14","Orlando Magic","Brooklyn Nets",-950,640,14.0,224.5,203,1,0.87,0.5,0.1,2,3],["2025-11-14","San Antonio Spurs","Golden State Warriors",-146,124,2.5,233.5,217,0,0.571,0.7,0.5,2,2],["2025-11-14","Houston Rockets","Portland Trail Blazers",-320,260,7.5,236.5,256,1,0.733,0.7,0.6,2,2],["2025-11-14","Detroit Pistons","Philadelphia 76ers",-142,112,-0.5,232.5,219,1,0.554,0.9,0.6,2,3],["2025-11-15","Milwaukee Bucks","Los Angeles Lakers",-126,108,1.5,229.5,214,0,0.537,0.6,0.7,1,1],["2025-11-15","Charlotte Hornets","Oklahoma City Thunder",1100,-2200,-17.5,224.5,205,0,0.08,0.3,0.9,1,3],["2025-11-15","Minnesota Timberwolves","Denver Nuggets",-104,-112,-1.0,237.5,235,0,0.491,0.7,0.9,1,3],["2025-11-15","Cleveland Cavaliers","Memphis Grizzlies",-480,370,10.5,241.5,208,1,0.795,0.6,0.2,2,3],["2025-11-15","Indiana Pacers","Toronto Raptors",205,-250,-6.0,235.5,240,0,0.315,0.1,0.6,2,2],["2025-11-16","Phoenix Suns","Atlanta Hawks",-118,100,1.5,226.5,246,0,0.52,0.7,0.7,3,3],["2025-11-16","Houston Rockets","Orlando Magic",-295,240,7.5,223.5,230,1,0.717,0.8,0.6,2,2],["2025-11-16","San Antonio Spurs","Sacramento Kings",-320,235,6.5,244.5,233,1,0.718,0.6,0.2,2,2],["2025-11-16","Washington Wizards","Brooklyn Nets",-138,118,2.5,231.5,235,0,0.558,0.0,0.1,4,2],["2025-11-16","Boston Celtics","LA Clippers",-220,184,5.5,218.5,239,1,0.661,0.6,0.3,4,2],["2025-11-16","New Orleans Pelicans","Golden State Warriors",380,-500,-11.0,226.5,230,0,0.2,0.2,0.5,2,2],["2025-11-16","Dallas Mavericks","Portland Trail Blazers",130,-154,-3.0,236.5,271,1,0.418,0.2,0.5,2,2],["2025-11-16","Utah Jazz","Chicago Bulls",160,-190,-5.0,245.5,297,1,0.37,0.3,0.5,3,4],["2025-11-17","Minnesota Timberwolves","Dallas Mavericks",-1000,660,14.0,232.5,216,1,0.874,0.6,0.3,2,1],["2025-11-17","New Orleans Pelicans","Oklahoma City Thunder",1300,-5000,-22.5,226.5,235,0,0.068,0.2,0.9,1,2],["2025-11-17","Miami Heat","New York Knicks",-125,-102,1.5,244.5,228,1,0.524,0.5,0.6,3,3],["2025-11-17","Denver Nuggets","Chicago Bulls",-670,490,12.5,241.5,257,0,0.837,0.9,0.4,2,1],["2025-11-17","Detroit Pistons","Indiana Pacers",-340,250,8.5,231.5,239,1,0.73,0.9,0.1,3,2],["2025-11-17","Philadelphia 76ers","LA Clippers",-210,176,5.5,221.5,218,1,0.652,0.5,0.2,3,1],["2025-11-17","Cleveland Cavaliers","Milwaukee Bucks",-240,198,5.5,234.5,224,1,0.678,0.6,0.5,2,2],["2025-11-17","Toronto Raptors","Charlotte Hornets",-400,285,9.5,242.5,218,1,0.755,0.7,0.2,2,2],["2025-11-18","Brooklyn Nets","Boston Celtics",420,-560,-11.0,222.5,212,0,0.185,0.2,0.6,2,2],["2025-11-18","Atlanta Hawks","Detroit Pistons",108,-138,-1.5,226.5,232,0,0.453,0.8,1.0,2,1],["2025-11-18","Orlando Magic","Golden State Warriors",116,-134,-2.0,223.5,234,1,0.447,0.6,0.5,2,2],["2025-11-18","Los Angeles Lakers","Utah Jazz",-750,530,13.0,240.5,266,1,0.848,0.8,0.3,3,2],["2025-11-18","Portland Trail Blazers","Phoenix Suns",-126,108,2.0,235.5,237,0,0.537,0.5,0.7,2,2],["2025-11-18","San Antonio Spurs","Memphis Grizzlies",-240,198,6.0,234.5,212,1,0.678,0.6,0.2,2,3],["2025-11-19","Minnesota Timberwolves","Washington Wizards",-1400,830,16.5,240.5,229,1,0.897,0.7,0.0,2,3],["2025-11-19","New Orleans Pelicans","Denver Nuggets",400,-520,-11.0,234.5,243,0,0.193,0.2,0.8,2,2],["2025-11-19","Oklahoma City Thunder","Sacramento Kings",-3000,1300,18.5,231.5,212,1,0.931,0.9,0.2,2,3],["2025-11-19","Indiana Pacers","Charlotte Hornets",108,-126,-1.5,237.5,245,1,0.463,0.1,0.2,2,2],["2025-11-19","Portland Trail Blazers","Chicago Bulls",134,-158,-3.5,244.5,243,0,0.411,0.4,0.4,1,2],["2025-11-19","Cleveland Cavaliers","Houston Rockets",104,-122,-1.0,232.5,218,0,0.471,0.7,0.9,2,3],["2025-11-19","Philadelphia 76ers","Toronto Raptors",120,-142,-2.5,233.5,233,0,0.437,0.5,0.8,2,2],["2025-11-19","Miami Heat","Golden State Warriors",-430,340,10.5,234.5,206,1,0.781,0.5,0.5,2,1],["2025-11-19","Dallas Mavericks","New York Knicks",300,-375,-8.5,233.5,224,0,0.241,0.2,0.6,2,2],["2025-11-20","Orlando Magic","LA Clippers",-255,210,6.5,218.5,230,1,0.69,0.7,0.2,2,3],["2025-11-20","Milwaukee Bucks","Philadelphia 76ers",110,-130,-1.5,223.5,237,0,0.457,0.4,0.4,3,1],["2025-11-20","San Antonio Spurs","Atlanta Hawks",-104,-112,-1.0,233.5,261,1,0.491,0.6,0.7,2,2],["2025-11-20","Memphis Grizzlies","Sacramento Kings",-148,126,3.0,234.5,233,1,0.574,0.1,0.2,2,1],["2025-11-21","Chicago Bulls","Miami Heat",-130,110,2.0,250.5,250,0,0.543,0.4,0.6,2,2],["2025-11-21","Houston Rockets","Denver Nuggets",-146,124,2.5,234.5,221,0,0.571,0.9,0.8,2,2],["2025-11-21","Golden State Warriors","Portland Trail Blazers",-400,315,10.0,236.5,250,0,0.769,0.5,0.3,2,2],["2025-11-21","Utah Jazz","Oklahoma City Thunder",980,-1800,-16.5,234.5,256,0,0.089,0.3,0.9,3,2],["2025-11-21","Dallas Mavericks","New Orleans Pelicans",-154,130,3.5,233.5,233,1,0.582,0.2,0.2,2,2],["2025-11-21","Boston Celtics","Brooklyn Nets",-750,530,13.5,222.0,218,0,0.848,0.6,0.2,3,3],["2025-11-21","Cleveland Cavaliers","Indiana Pacers",-820,570,13.5,241.5,229,1,0.857,0.7,0.2,2,2],["2025-11-21","Toronto Raptors","Washington Wizards",-850,500,14.5,239.5,250,1,0.843,0.9,0.0,2,2],["2025-11-21","Phoenix Suns","Minnesota Timberwolves",160,-190,-4.5,230.5,227,1,0.37,0.8,0.8,3,2],["2025-11-22","Denver Nuggets","Sacramento Kings",-590,440,11.5,239.5,251,0,0.822,0.9,0.1,1,2],["2025-11-22","Milwaukee Bucks","Detroit Pistons",270,-335,-8.0,225.5,245,0,0.26,0.4,1.0,2,4],["2025-11-22","Orlando Magic","New York Knicks",-126,108,2.0,230.5,254,1,0.537,0.7,0.7,2,3],["2025-11-22","New Orleans Pelicans","Atlanta Hawks",350,-450,-9.5,232.5,213,0,0.214,0.2,0.6,1,2],["2025-11-22","Dallas Mavericks","Memphis Grizzlies",-110,-106,1.0,229.5,198,0,0.504,0.3,0.2,1,2],["2025-11-22","Chicago Bulls","Washington Wizards",-650,480,12.5,246.5,241,1,0.834,0.3,0.0,1,1],["2025-11-22","Charlotte Hornets","LA Clippers",-116,-102,1.5,227.5,247,0,0.515,0.2,0.1,3,2],["2025-11-23","Utah Jazz","Los Angeles Lakers",315,-400,-9.5,245.5,214,0,0.231,0.3,0.8,2,5],["2025-11-23","Cleveland Cavaliers","LA Clippers",-295,240,7.5,229.5,225,1,0.717,0.7,0.2,2,1],["2025-11-23","Toronto Raptors","Brooklyn Nets",-520,400,11.5,229.5,228,1,0.807,0.9,0.3,2,2],["2025-11-23","Phoenix Suns","San Antonio Spurs",-126,108,1.5,234.5,213,1,0.537,0.8,0.6,2,3],["2025-11-23","Atlanta Hawks","Charlotte Hornets",-295,240,8.0,228.5,223,1,0.717,0.7,0.2,1,1],["2025-11-23","Oklahoma City Thunder","Portland Trail Blazers",-1500,870,16.5,233.5,217,1,0.901,0.9,0.3,2,2],["2025-11-23","Boston Celtics","Orlando Magic",-190,160,4.5,223.5,267,1,0.63,0.5,0.7,2,1],["2025-11-23","Philadelphia 76ers","Miami Heat",-118,100,1.0,240.5,244,0,0.52,0.5,0.7,3,2],["2025-11-24","Indiana Pacers","Detroit Pistons",315,-400,-9.5,236.5,239,0,0.231,0.1,1.0,3,2],["2025-11-24","Golden State Warriors","Utah Jazz",-720,520,13.5,239.5,251,1,0.845,0.4,0.3,3,1],["2025-11-24","Milwaukee Bucks","Portland Trail Blazers",-112,-104,1.0,230.5,218,0,0.509,0.3,0.3,2,1],["2025-11-24","Brooklyn Nets","New York Knicks",490,-700,-12.5,228.5,213,0,0.162,0.3,0.7,1,2],["2025-11-24","Sacramento Kings","Minnesota Timberwolves",385,-500,-10.5,238.5,229,1,0.198,0.2,0.7,2,3],["2025-11-24","New Orleans Pelicans","Chicago Bulls",168,-200,-5.0,243.5,273,1,0.359,0.1,0.4,2,2],["2025-11-24","Miami Heat","Dallas Mavericks",-260,215,7.5,240.5,208,1,0.695,0.7,0.3,1,2],["2025-11-24","Phoenix Suns","Houston Rockets",205,-250,-6.5,222.5,206,0,0.315,0.8,0.8,1,3],["2025-11-24","Toronto Raptors","Cleveland Cavaliers",-122,104,1.5,231.5,209,1,0.529,0.9,0.7,1,1],["2025-11-24","Memphis Grizzlies","Denver Nuggets",220,-270,-6.5,235.5,240,0,0.3,0.3,0.8,2,2],["2025-11-25","Washington Wizards","Atlanta Hawks",420,-560,-11.0,240.5,245,1,0.185,0.0,0.7,3,2],["2025-11-25","Philadelphia 76ers","Orlando Magic",176,-210,-5.0,229.5,247,0,0.348,0.4,0.7,2,2],["2025-11-25","Los Angeles Lakers","LA Clippers",-255,210,6.5,227.5,253,1,0.69,0.8,0.2,2,2],["2025-11-26","Golden State Warriors","Houston Rockets",-176,148,3.5,224.5,204,0,0.613,0.5,0.8,2,2],["2025-11-26","New Orleans Pelicans","Memphis Grizzlies",132,-156,-3.5,235.5,261,0,0.414,0.1,0.3,2,2],["2025-11-26","Oklahoma City Thunder","Minnesota Timberwolves",-480,380,10.5,226.5,218,1,0.799,0.9,0.6,3,2],["2025-11-26","Toronto Raptors","Indiana Pacers",-430,340,10.5,233.5,192,1,0.781,0.9,0.1,2,2],["2025-11-26","Boston Celtics","Detroit Pistons",102,-120,-1.5,233.5,231,1,0.476,0.6,1.0,3,2],["2025-11-26","Charlotte Hornets","New York Knicks",215,-260,-6.5,242.5,230,0,0.305,0.1,0.7,3,2],["2025-11-26","Sacramento Kings","Phoenix Suns",152,-180,-4.5,233.5,212,0,0.382,0.2,0.8,2,2],["2025-11-26","Portland Trail Blazers","San Antonio Spurs",-170,132,2.5,240.5,217,0,0.594,0.3,0.6,2,3],["2025-11-26","Miami Heat","Milwaukee Bucks",-450,350,10.5,236.5,209,1,0.786,0.8,0.3,2,2],["2025-11-28","LA Clippers","Memphis Grizzlies",-270,220,6.5,224.5,219,0,0.7,0.2,0.4,3,2],["2025-11-28","Denver Nuggets","San Antonio Spurs",-270,220,6.5,238.5,275,0,0.7,0.8,0.7,4,2],["2025-11-28","Oklahoma City Thunder","Phoenix Suns",-1100,600,14.5,223.5,242,1,0.865,1.0,0.8,2,2],["2025-11-28","Utah Jazz","Sacramento Kings",-146,124,3.0,242.5,247,1,0.571,0.2,0.2,4,2],["2025-11-28","Atlanta Hawks","Cleveland Cavaliers",205,-250,-7.0,236.5,253,1,0.315,0.7,0.6,3,4],["2025-11-28","Detroit Pistons","Orlando Magic",-164,138,3.5,230.5,221,0,0.597,0.9,0.7,2,3],["2025-11-28","Charlotte Hornets","Chicago Bulls",120,-154,-2.5,249.5,239,1,0.428,0.1,0.3,2,4],["2025-11-28","Indiana Pacers","Washington Wizards",-235,194,6.5,240.5,205,1,0.673,0.1,0.1,2,3],["2025-11-28","Los Angeles Lakers","Dallas Mavericks",-420,330,9.5,232.5,248,1,0.776,0.8,0.3,3,4],["2025-11-28","Brooklyn Nets","Philadelphia 76ers",220,-270,-7.5,222.5,218,0,0.3,0.3,0.4,4,3],["2025-11-28","New York Knicks","Milwaukee Bucks",-280,230,7.5,231.5,227,1,0.709,0.7,0.2,2,2],["2025-11-29","LA Clippers","Dallas Mavericks",-405,320,9.5,224.5,224,0,0.771,0.2,0.2,1,1],["2025-11-29","Phoenix Suns","Denver Nuggets",140,-166,-4.0,233.5,242,0,0.4,0.7,0.7,1,1],["2025-11-29","Golden State Warriors","New Orleans Pelicans",-460,360,10.0,228.5,200,1,0.791,0.5,0.1,3,3],["2025-11-29","Miami Heat","Detroit Pistons",-168,142,4.0,238.5,273,0,0.603,0.8,0.8,3,1],["2025-11-29","Milwaukee Bucks","Brooklyn Nets",-560,420,11.5,217.5,215,1,0.815,0.2,0.2,1,1],["2025-11-29","Indiana Pacers","Chicago Bulls",130,-154,-2.5,240.5,204,1,0.418,0.2,0.3,1,1],["2025-11-29","Charlotte Hornets","Toronto Raptors",225,-275,-6.5,233.5,229,1,0.296,0.2,0.9,1,3],["2025-11-29","Minnesota Timberwolves","Boston Celtics",-230,190,5.5,229.5,234,1,0.669,0.6,0.7,3,3],["2025-11-30","Los Angeles Lakers","New Orleans Pelicans",-1200,750,15.5,228.5,254,1,0.887,0.8,0.1,2,1],["2025-11-30","Sacramento Kings","Memphis Grizzlies",122,-144,-3.0,233.5,222,0,0.433,0.2,0.4,2,2],["2025-11-30","Minnesota Timberwolves","San Antonio Spurs",-188,158,4.5,233.5,237,1,0.627,0.6,0.7,1,2],["2025-11-30","Philadelphia 76ers","Atlanta Hawks",-156,122,2.5,232.5,276,0,0.575,0.5,0.7,2,2],["2025-11-30","Cleveland Cavaliers","Boston Celtics",-295,240,7.5,235.5,232,0,0.717,0.5,0.6,2,1],["2025-11-30","Portland Trail Blazers","Oklahoma City Thunder",460,-620,-11.5,233.5,238,0,0.172,0.3,1.0,4,2],["2025-11-30","New York Knicks","Toronto Raptors",-320,260,8.5,229.5,210,1,0.733,0.7,0.9,2,1],["2025-11-30","Utah Jazz","Houston Rockets",410,-550,-11.5,233.5,230,0,0.188,0.3,0.8,2,4],["2025-12-01","Brooklyn Nets","Charlotte Hornets",168,-200,-4.5,228.5,219,1,0.359,0.2,0.3,2,2],["2025-12-01","Washington Wizards","Milwaukee Bucks",340,-430,-10.5,232.5,255,1,0.219,0.1,0.2,3,2],["2025-12-01","Detroit Pistons","Atlanta Hawks",-375,300,9.5,232.5,197,1,0.759,0.8,0.7,2,1],["2025-12-01","Miami Heat","LA Clippers",-245,205,6.0,236.5,263,1,0.684,0.7,0.2,2,2],["2025-12-01","Denver Nuggets","Dallas Mavericks",-550,410,11.5,235.5,252,0,0.812,0.7,0.3,2,2],["2025-12-01","Orlando Magic","Chicago Bulls",-400,315,9.5,239.5,245,1,0.769,0.8,0.3,3,2],["2025-12-01","Utah Jazz","Houston Rockets",450,-600,-11.5,235.5,258,1,0.175,0.3,0.8,1,1],["2025-12-01","Los Angeles Lakers","Phoenix Suns",-225,172,5.5,231.5,233,0,0.653,0.8,0.6,1,2],["2025-12-01","Indiana Pacers","Cleveland Cavaliers",158,-188,-4.5,231.5,254,0,0.373,0.3,0.5,2,1],["2025-12-02","Golden State Warriors","Oklahoma City Thunder",410,-550,-11.5,223.5,236,0,0.188,0.5,1.0,3,2],["2025-12-02","San Antonio Spurs","Memphis Grizzlies",-205,172,5.0,232.5,245,1,0.646,0.6,0.5,2,2],["2025-12-02","Boston Celtics","New York Knicks",100,-118,-1.5,230.5,240,1,0.48,0.7,0.7,2,2],["2025-12-02","New Orleans Pelicans","Minnesota Timberwolves",500,-700,-12.5,230.5,291,0,0.16,0.1,0.6,2,2],["2025-12-02","Toronto Raptors","Portland Trail Blazers",-205,172,5.0,230.5,239,1,0.646,0.8,0.3,2,2],["2025-12-02","Philadelphia 76ers","Washington Wizards",-900,610,13.5,235.5,223,1,0.865,0.4,0.2,2,1],["2025-12-03","New York Knicks","Charlotte Hornets",-390,310,9.5,235.5,223,1,0.765,0.6,0.2,1,2],["2025-12-03","Indiana Pacers","Denver Nuggets",245,-300,-8.5,238.5,255,0,0.279,0.3,0.6,2,2],["2025-12-03","Cleveland Cavaliers","Portland Trail Blazers",-430,340,10.0,243.5,232,0,0.781,0.5,0.2,2,1],["2025-12-03","Atlanta Hawks","LA Clippers",-120,102,1.5,225.5,207,0,0.524,0.6,0.2,2,2],["2025-12-03","Dallas Mavericks","Miami Heat",154,-184,-4.5,237.5,226,1,0.378,0.4,0.7,2,2],["2025-12-03","Chicago Bulls","Brooklyn Nets",-330,265,7.5,231.5,216,0,0.737,0.3,0.3,2,2],["2025-12-03","Houston Rockets","Sacramento Kings",-1400,830,15.5,231.5,216,1,0.897,0.8,0.2,2,3],["2025-12-03","Milwaukee Bucks","Detroit Pistons",162,-194,-4.5,228.5,222,1,0.366,0.2,0.8,2,2],["2025-12-03","Orlando Magic","San Antonio Spurs",-335,270,8.5,235.5,226,0,0.74,0.8,0.6,2,1],["2025-12-04","Brooklyn Nets","Utah Jazz",162,-194,-5.5,231.5,233,0,0.366,0.4,0.4,1,3],["2025-12-04","New Orleans Pelicans","Minnesota Timberwolves",450,-600,-12.0,232.5,241,0,0.175,0.1,0.6,2,2],["2025-12-04","Washington Wizards","Boston Celtics",350,-450,-10.5,231.5,247,0,0.214,0.2,0.7,2,2],["2025-12-04","Toronto Raptors","Los Angeles Lakers",-136,116,2.5,228.5,243,0,0.555,0.8,0.8,2,3],["2025-12-04","Philadelphia 76ers","Golden State Warriors",-168,142,4.0,223.5,197,1,0.603,0.5,0.5,2,2],["2025-12-05","Detroit Pistons","Portland Trail Blazers",-330,265,8.0,235.5,238,1,0.737,0.7,0.3,2,2],["2025-12-05","Oklahoma City Thunder","Dallas Mavericks",-1400,830,15.5,229.5,243,1,0.897,1.0,0.5,3,2],["2025-12-05","Houston Rockets","Phoenix Suns",-370,295,9.0,218.5,215,1,0.757,0.8,0.6,2,4],["2025-12-05","Milwaukee Bucks","Philadelphia 76ers",104,-122,-1.0,221.5,217,0,0.471,0.2,0.5,2,1],["2025-12-05","Memphis Grizzlies","LA Clippers",110,-130,-2.0,222.5,205,1,0.457,0.5,0.2,3,2],["2025-12-05","Chicago Bulls","Indiana Pacers",-200,168,5.0,235.5,225,0,0.641,0.3,0.3,2,2],["2025-12-05","Cleveland Cavaliers","San Antonio Spurs",-205,172,5.0,238.5,247,1,0.646,0.5,0.7,2,2],["2025-12-05","New York Knicks","Utah Jazz",-1200,750,16.0,242.5,258,1,0.887,0.7,0.4,2,1],["2025-12-05","Orlando Magic","Miami Heat",-255,210,6.0,241.5,211,1,0.69,0.7,0.7,2,2],["2025-12-05","Boston Celtics","Los Angeles Lakers",-350,280,9.5,227.5,231,1,0.747,0.8,0.8,1,1],["2025-12-05","Atlanta Hawks","Denver Nuggets",-194,150,4.5,245.5,267,0,0.623,0.5,0.6,2,2],["2025-12-05","Toronto Raptors","Charlotte Hornets",-250,205,6.5,230.5,197,0,0.685,0.7,0.2,1,2],["2025-12-06","Minnesota Timberwolves","LA Clippers",-330,265,8.0,227.5,215,1,0.737,0.6,0.2,2,1],["2025-12-06","Cleveland Cavaliers","Golden State Warriors",-390,310,9.0,229.5,193,0,0.765,0.5,0.4,1,2],["2025-12-06","Miami Heat","Sacramento Kings",-375,300,9.0,241.5,238,0,0.759,0.7,0.2,1,3],["2025-12-06","Dallas Mavericks","Houston Rockets",205,-250,-6.5,221.5,231,1,0.315,0.4,0.8,1,1],["2025-12-06","Brooklyn Nets","New Orleans Pelicans",-176,148,3.5,227.5,220,1,0.613,0.4,0.1,2,2],["2025-12-06","Washington Wizards","Atlanta Hawks",320,-405,-9.5,237.5,247,0,0.229,0.2,0.4,2,1],["2025-12-06","Detroit Pistons","Milwaukee Bucks",-620,400,10.5,221.5,236,1,0.812,0.7,0.2,1,1],["2025-12-07","New York Knicks","Orlando Magic",-124,106,1.5,229.5,206,1,0.533,0.7,0.7,2,2],["2025-12-07","Toronto Raptors","Boston Celtics",300,-430,-9.5,227.5,234,0,0.236,0.6,0.8,2,2],["2025-12-07","Charlotte Hornets","Denver Nuggets",380,-500,-10.5,236.5,221,0,0.2,0.3,0.6,2,2],["2025-12-07","Memphis Grizzlies","Portland Trail Blazers",-134,114,2.5,232.5,215,1,0.551,0.6,0.3,2,2],["2025-12-07","Chicago Bulls","Golden State Warriors",-104,-112,-1.5,229.5,214,0,0.491,0.3,0.4,2,1],["2025-12-07","Philadelphia 76ers","Los Angeles Lakers",124,-146,-3.0,233.5,220,0,0.429,0.6,0.8,2,2],["2025-12-07","Utah Jazz","Oklahoma City Thunder",520,-900,-13.5,232.5,232,0,0.152,0.4,1.0,2,2],["2025-12-08","Indiana Pacers","Sacramento Kings",-164,138,3.5,231.5,221,1,0.597,0.4,0.3,3,2],["2025-12-08","Minnesota Timberwolves","Phoenix Suns",-340,275,8.5,226.5,213,0,0.743,0.7,0.5,2,3],["2025-12-08","New Orleans Pelicans","San Antonio Spurs",275,-340,-8.5,238.5,267,0,0.257,0.1,0.7,2,3],["2025-12-09","Orlando Magic","Miami Heat",-120,102,1.5,235.5,225,1,0.524,0.7,0.6,2,3],["2025-12-09","Toronto Raptors","New York Knicks",205,-250,-6.5,226.5,218,0,0.315,0.5,0.8,2,2],["2025-12-10","Los Angeles Lakers","San Antonio Spurs",-270,220,7.0,242.5,251,0,0.7,0.8,0.7,3,2],["2025-12-10","Oklahoma City Thunder","Phoenix Suns",-1408,830,15.5,221.5,227,1,0.897,1.0,0.6,3,2],["2025-12-11","Milwaukee Bucks","Boston Celtics",315,-400,-9.5,223.5,217,1,0.231,0.2,0.8,5,4],["2025-12-11","Houston Rockets","LA Clippers",-375,300,9.0,221.5,228,1,0.759,0.7,0.2,5,5],["2025-12-11","New Orleans Pelicans","Portland Trail Blazers",146,-174,-4.0,242.5,263,1,0.39,0.1,0.3,3,4],["2025-12-11","Sacramento Kings","Denver Nuggets",390,-510,-10.5,239.5,241,0,0.196,0.3,0.7,3,4],["2025-12-12","Philadelphia 76ers","Indiana Pacers",-225,188,5.5,221.5,220,1,0.666,0.5,0.5,5,4],["2025-12-12","Detroit Pistons","Atlanta Hawks",-275,225,6.5,232.5,257,1,0.704,0.7,0.5,6,6],["2025-12-12","Charlotte Hornets","Chicago Bulls",120,-142,-2.5,229.5,255,0,0.437,0.3,0.2,5,5],["2025-12-12","Washington Wizards","Cleveland Cavaliers",980,-1786,-17.0,245.5,256,0,0.089,0.2,0.4,6,6],["2025-12-12","Golden State Warriors","Minnesota Timberwolves",-200,168,5.5,228.5,247,0,0.641,0.4,0.6,5,4],["2025-12-12","Dallas Mavericks","Brooklyn Nets",-290,235,7.0,219.5,230,1,0.714,0.5,0.4,6,6],["2025-12-12","Memphis Grizzlies","Utah Jazz",-260,215,7.5,243.5,256,0,0.695,0.7,0.3,5,5],["2025-12-13","Oklahoma City Thunder","San Antonio Spurs",-490,380,10.5,232.5,220,0,0.799,1.0,0.7,3,3],["2025-12-13","Orlando Magic","New York Knicks",150,-178,-4.0,225.5,252,0,0.385,0.7,0.8,4,4],["2025-12-14","Chicago Bulls","New Orleans Pelicans",-172,144,4.0,247.5,218,0,0.607,0.2,0.2,2,3],["2025-12-14","Portland Trail Blazers","Golden State Warriors",168,-200,-4.5,237.5,267,1,0.359,0.3,0.4,3,2],["2025-12-14","Phoenix Suns","Los Angeles Lakers",-116,-102,1.0,232.5,230,0,0.515,0.5,0.7,4,4],["2025-12-14","Minnesota Timberwolves","Sacramento Kings",-461,360,10.0,235.5,220,1,0.791,0.6,0.3,2,3],["2025-12-14","Indiana Pacers","Washington Wizards",-420,330,10.0,233.5,197,0,0.776,0.4,0.2,2,2],["2025-12-14","Brooklyn Nets","Milwaukee Bucks",102,-118,-1.5,215.5,209,1,0.478,0.4,0.3,2,3],["2025-12-14","Atlanta Hawks","Philadelphia 76ers",-196,164,4.5,226.5,237,1,0.636,0.5,0.6,2,2],["2025-12-14","Cleveland Cavaliers","Charlotte Hornets",-649,480,11.5,233.5,230,0,0.834,0.5,0.3,2,2],["2025-12-15","Denver Nuggets","Houston Rockets",-102,-116,-1.0,237.5,253,1,0.485,0.7,0.7,4,4],["2025-12-15","LA Clippers","Memphis Grizzlies",-220,184,6.0,229.5,224,0,0.661,0.2,0.7,4,3],["2025-12-15","Boston Celtics","Detroit Pistons",-118,-102,1.5,231.5,217,0,0.517,0.7,0.7,4,3],["2025-12-15","Miami Heat","Toronto Raptors",-190,158,4.5,234.5,202,0,0.628,0.5,0.4,6,6],["2025-12-15","Utah Jazz","Dallas Mavericks",-102,-116,-1.0,241.5,273,1,0.485,0.4,0.6,3,3],["2025-12-16","New York Knicks","San Antonio Spurs",-136,116,2.5,233.5,237,1,0.555,0.9,0.7,3,3],["2025-12-17","Chicago Bulls","Cleveland Cavaliers",188,-225,-5.5,243.5,238,1,0.334,0.2,0.4,3,3],["2025-12-17","Minnesota Timberwolves","Memphis Grizzlies",-260,215,6.5,226.5,226,0,0.695,0.7,0.7,3,2],["2025-12-18","Portland Trail Blazers","Sacramento Kings",-280,210,6.5,243.5,267,1,0.696,0.3,0.3,4,4],["2025-12-18","Phoenix Suns","Golden State Warriors",102,-130,-1.5,231.5,197,1,0.467,0.4,0.4,4,4],["2025-12-18","Utah Jazz","Los Angeles Lakers",235,-319,-7.5,248.5,278,0,0.282,0.5,0.7,3,4],["2025-12-18","Dallas Mavericks","Detroit Pistons",-104,-122,-1.5,232.5,230,1,0.481,0.5,0.7,3,3],["2025-12-18","Denver Nuggets","Orlando Magic",-225,172,5.5,238.5,241,1,0.653,0.7,0.6,3,5],["2025-12-18","Oklahoma City Thunder","LA Clippers",-1493,870,16.5,221.5,223,1,0.901,0.9,0.1,5,3],["2025-12-18","San Antonio Spurs","Washington Wizards",-1408,810,15.5,240.5,213,1,0.895,0.7,0.3,2,4],["2025-12-18","Brooklyn Nets","Miami Heat",340,-500,-10.5,235.5,201,0,0.214,0.4,0.4,4,3],["2025-12-18","Charlotte Hornets","Atlanta Hawks",-150,118,2.5,246.5,259,1,0.567,0.4,0.5,4,4],["2025-12-18","Milwaukee Bucks","Toronto Raptors",154,-184,-4.5,218.5,216,0,0.378,0.3,0.4,4,3],["2025-12-18","New Orleans Pelicans","Houston Rockets",315,-400,-9.5,235.5,261,1,0.231,0.3,0.6,4,3],["2025-12-18","Indiana Pacers","New York Knicks",120,-154,-2.5,225.5,227,0,0.428,0.4,0.9,4,2],["2025-12-19","Atlanta Hawks","San Antonio Spurs",215,-290,-6.5,237.5,224,0,0.299,0.4,0.7,1,1],["2025-12-19","Cleveland Cavaliers","Chicago Bulls",-350,255,8.5,238.5,261,0,0.734,0.3,0.2,2,2],["2025-12-19","New York Knicks","Philadelphia 76ers",-156,122,3.5,234.5,223,0,0.575,0.9,0.5,1,5],["2025-12-19","Boston Celtics","Miami Heat",-461,320,9.5,230.5,245,1,0.775,0.7,0.4,4,1],["2025-12-19","Minnesota Timberwolves","Oklahoma City Thunder",190,-250,-6.5,230.5,219,1,0.326,0.7,0.9,2,1],["2025-12-20","Golden State Warriors","Phoenix Suns",-174,136,3.5,233.5,235,1,0.6,0.4,0.4,2,2],["2025-12-20","Sacramento Kings","Portland Trail Blazers",300,-429,-9.5,229.5,191,0,0.236,0.2,0.4,2,2],["2025-12-20","LA Clippers","Los Angeles Lakers",-188,146,4.5,224.5,191,1,0.616,0.1,0.7,2,2],["2025-12-20","Utah Jazz","Orlando Magic",310,-441,-9.5,243.5,255,0,0.23,0.5,0.5,2,2],["2025-12-20","Memphis Grizzlies","Washington Wizards",-800,480,13.5,228.5,252,0,0.838,0.7,0.3,3,2],["2025-12-20","Philadelphia 76ers","Dallas Mavericks",124,-158,-2.5,228.5,235,1,0.422,0.6,0.6,1,2],["2025-12-20","New Orleans Pelicans","Indiana Pacers",-235,180,5.5,238.5,237,1,0.663,0.3,0.4,2,2],["2025-12-20","Denver Nuggets","Houston Rockets",116,-148,-2.5,234.5,216,0,0.437,0.8,0.6,2,2],["2025-12-20","Toronto Raptors","Boston Celtics",-200,154,4.5,216.5,208,0,0.629,0.4,0.7,2,1],["2025-12-20","Detroit Pistons","Charlotte Hornets",-370,265,8.5,239.5,198,1,0.742,0.6,0.5,2,2],["2025-12-21","Atlanta Hawks","Chicago Bulls",-113,-113,-0.5,260.5,302,0,0.5,0.4,0.3,2,2],["2025-12-21","New York Knicks","Miami Heat",-194,150,4.5,230.5,257,1,0.623,0.8,0.3,2,2],["2025-12-21","Brooklyn Nets","Toronto Raptors",144,-186,-3.5,216.5,177,1,0.387,0.4,0.3,3,1],["2025-12-21","Washington Wizards","San Antonio Spurs",500,-847,-12.5,236.5,237,0,0.157,0.4,0.7,1,2],["2025-12-21","Minnesota Timberwolves","Milwaukee Bucks",-330,250,8.5,222.5,203,1,0.729,0.8,0.3,2,3],["2025-12-21","Sacramento Kings","Houston Rockets",420,-649,-11.5,229.5,249,1,0.182,0.1,0.6,1,1],["2025-12-22","Oklahoma City Thunder","Memphis Grizzlies",-671,430,12.5,233.5,222,1,0.822,0.8,0.7,3,2],["2025-12-22","Portland Trail Blazers","Detroit Pistons",255,-350,-8.5,233.5,212,0,0.266,0.4,0.7,2,2],["2025-12-22","Boston Celtics","Indiana Pacers",-500,340,9.5,231.5,198,1,0.786,0.7,0.4,2,2],["2025-12-22","New Orleans Pelicans","Dallas Mavericks",-180,140,3.5,242.5,232,1,0.607,0.4,0.6,2,2],["2025-12-22","Denver Nuggets","Utah Jazz",-5000,1300,21.5,249.5,247,1,0.932,0.7,0.5,2,2],["2025-12-22","Golden State Warriors","Orlando Magic",-170,132,3.5,230.5,217,1,0.594,0.4,0.6,2,2],["2025-12-22","Cleveland Cavaliers","Charlotte Hornets",-360,260,8.5,252.5,271,1,0.738,0.3,0.5,3,2],["2025-12-23","San Antonio Spurs","Oklahoma City Thunder",164,-215,-5.5,236.5,240,1,0.357,0.8,0.8,2,1],["2025-12-23","Minnesota Timberwolves","New York Knicks",-340,250,8.5,234.5,219,1,0.73,0.8,0.8,2,2],["2025-12-23","Sacramento Kings","Detroit Pistons",330,-420,-10.5,227.5,263,0,0.224,0.2,0.8,2,1],["2025-12-23","Portland Trail Blazers","Orlando Magic",108,-126,-4.5,232.5,216,0,0.463,0.4,0.5,1,1],["2025-12-23","Phoenix Suns","Los Angeles Lakers",-184,142,3.5,228.5,240,1,0.611,0.4,0.6,3,3],["2025-12-23","Utah Jazz","Memphis Grizzlies",196,-260,-6.5,242.5,265,0,0.319,0.4,0.6,1,1],["2025-12-23","LA Clippers","Houston Rockets",235,-319,-7.5,216.5,236,1,0.282,0.2,0.5,3,2],["2025-12-23","Miami Heat","Toronto Raptors",-225,188,5.5,227.5,203,0,0.666,0.2,0.3,2,2],["2025-12-23","Indiana Pacers","Milwaukee Bucks",104,-122,-1.5,216.5,205,0,0.471,0.3,0.3,1,2],["2025-12-23","Cleveland Cavaliers","New Orleans Pelicans",-420,330,9.5,248.5,259,1,0.776,0.4,0.5,1,1],["2025-12-23","Philadelphia 76ers","Brooklyn Nets",-391,280,8.5,217.5,220,0,0.752,0.7,0.5,3,2],["2025-12-23","Charlotte Hornets","Washington Wizards",-340,250,8.5,229.5,235,1,0.73,0.4,0.3,1,2],["2025-12-23","Dallas Mavericks","Denver Nuggets",-113,-113,-0.5,234.5,261,1,0.5,0.6,0.8,1,1],["2025-12-23","Atlanta Hawks","Chicago Bulls",-154,130,3.5,254.5,249,0,0.582,0.3,0.4,2,2],["2025-12-25","Denver Nuggets","Minnesota Timberwolves",-113,-113,-0.5,232.5,280,1,0.5,0.7,0.8,2,2],["2025-12-25","Los Angeles Lakers","Houston Rockets",196,-260,-6.5,233.5,215,0,0.319,0.5,0.4,2,2],["2025-12-25","New York Knicks","Cleveland Cavaliers",150,-194,-4.5,237.5,250,1,0.377,0.8,0.5,2,2],["2025-12-25","Oklahoma City Thunder","San Antonio Spurs",-559,370,11.5,246.5,219,0,0.799,0.7,0.8,2,2],["2025-12-25","Golden State Warriors","Dallas Mavericks",-410,290,9.5,227.5,242,1,0.758,0.5,0.6,3,2],["2025-12-26","Chicago Bulls","Philadelphia 76ers",200,-265,-6.5,239.5,211,1,0.315,0.5,0.6,3,3],["2025-12-26","Washington Wizards","Toronto Raptors",255,-350,-7.5,222.5,255,1,0.266,0.3,0.4,3,3],["2025-12-26","Orlando Magic","Charlotte Hornets",-150,118,2.5,236.5,225,0,0.567,0.5,0.4,3,3],["2025-12-26","Indiana Pacers","Boston Celtics",158,-205,-4.5,230.5,262,0,0.366,0.2,0.8,3,4],["2025-12-26","Portland Trail Blazers","LA Clippers",-146,114,2.5,228.5,222,0,0.559,0.4,0.3,3,3],["2025-12-26","Memphis Grizzlies","Milwaukee Bucks",-150,118,2.5,229.5,229,1,0.567,0.6,0.4,3,3],["2025-12-26","New Orleans Pelicans","Phoenix Suns",164,-215,-4.5,236.5,223,0,0.357,0.5,0.4,3,3],["2025-12-26","Utah Jazz","Detroit Pistons",230,-310,-7.5,248.5,260,1,0.286,0.4,0.8,3,3],["2025-12-26","Atlanta Hawks","Miami Heat",-136,106,1.5,254.5,237,0,0.543,0.2,0.2,3,3],["2025-12-27","Minnesota Timberwolves","Brooklyn Nets",-621,400,11.5,225.5,230,0,0.812,0.7,0.6,2,4],["2025-12-27","Miami Heat","Indiana Pacers",-290,215,6.5,237.5,258,1,0.701,0.2,0.2,1,1],["2025-12-27","Chicago Bulls","Milwaukee Bucks",-146,114,2.5,231.5,215,0,0.559,0.6,0.3,1,1],["2025-12-27","Atlanta Hawks","New York Knicks",136,-174,-3.5,242.5,253,0,0.4,0.2,0.8,1,2],["2025-12-27","San Antonio Spurs","Utah Jazz",-952,540,13.5,245.5,241,0,0.853,0.8,0.4,2,1],["2025-12-27","Orlando Magic","Denver Nuggets",-102,-125,-1.5,239.5,253,1,0.476,0.4,0.8,1,2],["2025-12-27","Sacramento Kings","Dallas Mavericks",106,-136,-1.5,235.5,220,1,0.457,0.2,0.5,4,2],["2025-12-27","New Orleans Pelicans","Phoenix Suns",146,-188,-3.5,236.5,237,0,0.384,0.5,0.5,1,1],["2025-12-27","Houston Rockets","Cleveland Cavaliers",-148,116,2.5,230.5,217,1,0.563,0.5,0.4,2,2],["2025-12-28","Toronto Raptors","Golden State Warriors",190,-250,-6.5,233.5,268,1,0.326,0.3,0.5,2,3],["2025-12-28","Oklahoma City Thunder","Philadelphia 76ers",-3030,1000,18.5,230.5,233,1,0.914,0.6,0.6,3,2],["2025-12-28","Portland Trail Blazers","Boston Celtics",280,-391,-8.5,230.5,222,1,0.248,0.4,0.8,2,2],["2025-12-28","Washington Wizards","Memphis Grizzlies",215,-290,-6.5,245.5,228,1,0.299,0.3,0.6,2,2],["2025-12-28","LA Clippers","Detroit Pistons",-140,110,1.5,228.5,211,1,0.551,0.4,0.7,2,2],["2025-12-28","Los Angeles Lakers","Sacramento Kings",-529,360,10.5,229.5,226,1,0.795,0.4,0.3,3,1],["2025-12-29","Oklahoma City Thunder","Atlanta Hawks",-1587,800,16.5,235.5,269,1,0.894,0.6,0.2,1,2],["2025-12-29","Washington Wizards","Phoenix Suns",370,-559,-11.5,229.5,216,0,0.201,0.4,0.6,1,2],["2025-12-29","Portland Trail Blazers","Dallas Mavericks",-142,112,2.5,230.5,247,1,0.554,0.4,0.4,1,2],["2025-12-29","San Antonio Spurs","Cleveland Cavaliers",-113,-113,1.5,240.5,214,0,0.5,0.8,0.4,2,2],["2025-12-29","New Orleans Pelicans","New York Knicks",285,-400,-8.5,252.5,255,0,0.245,0.5,0.8,2,2],["2025-12-29","Miami Heat","Denver Nuggets",-111,-115,-1.5,247.5,270,1,0.496,0.3,0.7,2,2],["2025-12-29","Toronto Raptors","Orlando Magic",200,-265,-6.5,216.5,213,1,0.315,0.4,0.5,1,2],["2025-12-29","Brooklyn Nets","Golden State Warriors",-115,-113,0.5,233.5,227,0,0.502,0.7,0.5,2,1],["2025-12-29","Charlotte Hornets","Milwaukee Bucks",146,-188,-4.5,226.5,236,0,0.384,0.5,0.4,3,2],["2025-12-29","Chicago Bulls","Minnesota Timberwolves",200,-265,-6.5,230.5,237,0,0.315,0.6,0.6,2,2],["2025-12-29","Houston Rockets","Indiana Pacers",-1587,750,16.5,220.5,245,1,0.889,0.5,0.2,2,2],["2025-12-30","Utah Jazz","Boston Celtics",128,-164,-3.5,249.5,248,0,0.414,0.4,0.7,3,2],["2025-12-30","Memphis Grizzlies","Philadelphia 76ers",-184,142,4.5,236.5,275,0,0.611,0.6,0.5,2,2],["2025-12-30","LA Clippers","Sacramento Kings",-330,250,8.5,216.5,221,1,0.729,0.5,0.3,2,2],["2025-12-30","Los Angeles Lakers","Detroit Pistons",132,-170,-3.5,237.5,234,0,0.406,0.5,0.7,2,2],["2025-12-31","Indiana Pacers","Orlando Magic",260,-360,-8.5,228.5,222,0,0.262,0.1,0.4,2,2],["2025-12-31","Toronto Raptors","Denver Nuggets",-220,168,5.5,231.5,209,0,0.648,0.5,0.6,2,2],["2025-12-31","Chicago Bulls","New Orleans Pelicans",-265,200,6.5,251.5,252,1,0.685,0.6,0.5,2,2],["2025-12-31","San Antonio Spurs","New York Knicks",-136,106,1.5,234.5,266,1,0.543,0.7,0.8,2,2],["2025-12-31","Cleveland Cavaliers","Phoenix Suns",-559,370,11.5,236.5,242,1,0.799,0.4,0.6,2,2],["2025-12-31","Charlotte Hornets","Golden State Warriors",220,-295,-7.5,237.5,257,0,0.295,0.5,0.6,2,2],["2025-12-31","Milwaukee Bucks","Washington Wizards",-1587,750,15.5,233.5,227,0,0.889,0.4,0.4,2,2],["2025-12-31","Oklahoma City Thunder","Portland Trail Blazers",-3448,1060,18.5,230.5,219,1,0.919,0.6,0.5,2,2],["2025-12-31","Atlanta Hawks","Minnesota Timberwolves",130,-166,-3.5,248.5,228,1,0.411,0.2,0.6,2,2],["2026-01-01","Sacramento Kings","Boston Celtics",240,-330,-7.5,234.5,226,0,0.277,0.2,0.7,2,2],["2026-01-01","Brooklyn Nets","Houston Rockets",1060,-3448,-18.5,218.5,216,0,0.081,0.6,0.5,3,3],["2026-01-01","Detroit Pistons","Miami Heat",-142,112,2.5,240.5,230,0,0.554,0.7,0.4,2,3],["2026-01-01","Dallas Mavericks","Philadelphia 76ers",-118,-108,0.5,231.5,231,0,0.51,0.4,0.5,3,2],["2026-01-01","LA Clippers","Utah Jazz",-7143,1500,22.5,224.5,219,1,0.94,0.5,0.4,2,2],["2026-01-02","Phoenix Suns","Sacramento Kings",-1000,560,14.5,226.5,231,1,0.857,0.6,0.2,2,1],["2026-01-02","Los Angeles Lakers","Memphis Grizzlies",-360,260,8.5,240.5,249,1,0.738,0.4,0.5,3,3],["2026-01-02","Chicago Bulls","Orlando Magic",320,-461,-9.5,225.5,235,1,0.225,0.7,0.5,2,2],["2026-01-02","Milwaukee Bucks","Charlotte Hornets",-235,180,5.5,241.5,243,1,0.663,0.4,0.4,2,2],["2026-01-02","Golden State Warriors","Oklahoma City Thunder",900,-2500,-17.5,220.5,225,0,0.094,0.6,0.6,2,2],["2026-01-02","Cleveland Cavaliers","Denver Nuggets",-901,520,13.5,237.5,221,1,0.848,0.5,0.6,2,2],["2026-01-02","Washington Wizards","Brooklyn Nets",-230,176,5.5,229.5,218,1,0.658,0.5,0.5,2,1],["2026-01-02","New Orleans Pelicans","Portland Trail Blazers",140,-180,-3.5,252.5,231,0,0.393,0.5,0.5,2,2],["2026-01-02","Indiana Pacers","San Antonio Spurs",-106,-120,-1.5,241.5,236,0,0.485,0.0,0.7,2,2],["2026-01-02","New York Knicks","Atlanta Hawks",-235,180,6.5,248.5,210,0,0.663,0.7,0.2,2,2],["2026-01-03","LA Clippers","Boston Celtics",162,-210,-4.5,220.5,261,0,0.36,0.6,0.7,2,2],["2026-01-03","Golden State Warriors","Utah Jazz",-400,285,9.5,251.5,237,1,0.755,0.5,0.4,1,2],["2026-01-03","Dallas Mavericks","Houston Rockets",350,-521,-10.5,227.5,214,1,0.209,0.3,0.6,2,2],["2026-01-03","San Antonio Spurs","Portland Trail Blazers",-188,146,4.5,235.5,225,0,0.616,0.7,0.6,1,1],["2026-01-03","Chicago Bulls","Charlotte Hornets",-154,120,2.5,244.5,211,0,0.572,0.7,0.4,1,1],["2026-01-03","New York Knicks","Philadelphia 76ers",-172,134,4.5,226.5,249,0,0.597,0.6,0.5,1,2],["2026-01-03","Miami Heat","Minnesota Timberwolves",230,-310,-7.5,232.5,240,0,0.286,0.5,0.6,2,3],["2026-01-03","Toronto Raptors","Atlanta Hawks",-205,158,3.5,225.5,251,1,0.634,0.5,0.3,3,1],["2026-01-04","Los Angeles Lakers","Memphis Grizzlies",-162,126,3.5,240.5,234,1,0.583,0.5,0.4,2,2],["2026-01-04","Sacramento Kings","Milwaukee Bucks",164,-215,-4.5,221.5,213,0,0.357,0.2,0.5,2,2],["2026-01-04","Phoenix Suns","Oklahoma City Thunder",440,-699,-11.5,229.5,213,1,0.175,0.6,0.6,2,2],["2026-01-04","Miami Heat","New Orleans Pelicans",-290,215,6.5,259.5,231,1,0.701,0.5,0.4,1,2],["2026-01-04","Brooklyn Nets","Denver Nuggets",-142,112,2.5,224.5,242,1,0.554,0.5,0.5,2,2],["2026-01-04","Orlando Magic","Indiana Pacers",-250,190,5.5,231.5,262,1,0.674,0.4,0.0,2,2],["2026-01-04","Cleveland Cavaliers","Detroit Pistons",-172,134,3.5,239.5,224,0,0.597,0.5,0.6,2,3],["2026-01-04","Washington Wizards","Minnesota Timberwolves",440,-699,-11.5,244.5,256,0,0.175,0.6,0.6,2,1],["2026-01-05","Houston Rockets","Phoenix Suns",-319,260,8.5,222.5,197,1,0.733,0.5,0.7,2,1],["2026-01-05","Detroit Pistons","New York Knicks",104,-122,-1.5,232.5,211,1,0.471,0.6,0.5,1,2],["2026-01-05","Boston Celtics","Chicago Bulls",-461,360,10.5,236.5,216,1,0.791,0.7,0.7,2,2],["2026-01-05","Toronto Raptors","Atlanta Hawks",-142,120,2.5,237.5,218,1,0.563,0.6,0.2,2,2],["2026-01-05","Philadelphia 76ers","Denver Nuggets",-952,640,14.5,228.5,249,0,0.87,0.6,0.4,2,1],["2026-01-05","Portland Trail Blazers","Utah Jazz",-225,188,6.0,242.5,254,1,0.666,0.6,0.3,2,2],["2026-01-05","LA Clippers","Golden State Warriors",150,-178,-4.0,221.5,205,1,0.385,0.6,0.6,2,2],["2026-01-05","Oklahoma City Thunder","Charlotte Hornets",-1149,700,15.5,235.5,221,0,0.88,0.6,0.5,1,2],["2026-01-06","New Orleans Pelicans","Los Angeles Lakers",190,-230,-5.5,245.5,214,0,0.331,0.3,0.5,2,2],["2026-01-06","Minnesota Timberwolves","Miami Heat",-198,166,5.5,238.5,216,1,0.639,0.6,0.6,2,2],["2026-01-06","Sacramento Kings","Dallas Mavericks",160,-190,-4.5,233.5,198,0,0.37,0.2,0.3,2,3],["2026-01-06","Washington Wizards","Orlando Magic",220,-270,-7.5,235.5,232,1,0.3,0.5,0.5,2,2],["2026-01-06","Indiana Pacers","Cleveland Cavaliers",198,-240,-6.5,236.5,236,0,0.322,0.0,0.5,2,2],["2026-01-06","Memphis Grizzlies","San Antonio Spurs",198,-240,-6.0,238.5,211,1,0.322,0.4,0.7,2,3],["2026-01-07","Memphis Grizzlies","Phoenix Suns",176,-210,-5.5,231.5,215,0,0.348,0.4,0.7,1,2],["2026-01-07","Brooklyn Nets","Orlando Magic",116,-136,-2.5,220.5,207,0,0.445,0.5,0.5,3,1],["2026-01-07","Atlanta Hawks","New Orleans Pelicans",-450,350,10.5,246.5,217,1,0.786,0.2,0.2,2,1],["2026-01-07","San Antonio Spurs","Los Angeles Lakers",-300,245,9.0,233.5,198,1,0.721,0.6,0.6,1,1],["2026-01-07","Oklahoma City Thunder","Utah Jazz",-1205,750,19.0,243.5,254,1,0.887,0.5,0.2,2,2],["2026-01-07","New York Knicks","LA Clippers",-198,166,5.0,222.5,234,1,0.639,0.4,0.7,2,2],["2026-01-07","Charlotte Hornets","Toronto Raptors",120,-142,-2.5,229.5,193,0,0.437,0.5,0.6,2,2],["2026-01-07","Philadelphia 76ers","Washington Wizards",-1099,700,16.5,234.5,241,1,0.88,0.5,0.6,2,1],["2026-01-07","Detroit Pistons","Chicago Bulls",-330,265,8.0,228.5,201,1,0.737,0.6,0.6,2,2],["2026-01-07","Golden State Warriors","Milwaukee Bucks",-240,198,6.5,228.5,233,1,0.678,0.6,0.5,2,3],["2026-01-07","Boston Celtics","Denver Nuggets",-375,300,9.5,231.5,224,0,0.759,0.8,0.4,2,2],["2026-01-07","Portland Trail Blazers","Houston Rockets",225,-275,-7.0,222.5,205,1,0.296,0.6,0.6,2,2]],"teams":[["Oklahoma City Thunder",38,31,7,0.816,18,3,13,4],["Detroit Pistons",37,28,9,0.757,15,3,13,6],["San Antonio Spurs",38,26,12,0.684,13,5,13,7],["Denver Nuggets",37,25,12,0.676,10,5,15,7],["New York Knicks",38,25,13,0.658,17,4,8,9],["Los Angeles Lakers",35,23,12,0.657,10,6,13,6],["Minnesota Timberwolves",37,24,13,0.649,13,6,11,7],["Houston Rockets",34,22,12,0.647,11,2,11,10],["Boston Celtics",36,23,13,0.639,11,6,12,7],["Toronto Raptors",38,23,15,0.605,12,8,11,7],["Phoenix Suns",37,22,15,0.595,12,5,10,10],["Philadelphia 76ers",35,20,15,0.571,10,9,10,6],["Cleveland Cavaliers",38,21,17,0.553,13,9,8,8],["Orlando Magic",38,21,17,0.553,12,6,9,11],["Miami Heat",37,20,17,0.541,13,6,7,11],["Golden State Warriors",38,20,18,0.526,12,5,8,13],["Portland Trail Blazers",38,18,20,0.474,9,9,9,11],["Atlanta Hawks",39,18,21,0.462,7,11,11,10],["Chicago Bulls",37,17,20,0.459,10,9,7,11],["Memphis Grizzlies",37,16,21,0.432,8,10,8,11],["Milwaukee Bucks",37,16,21,0.432,9,9,7,12],["Dallas Mavericks",37,14,23,0.378,10,10,4,13],["LA Clippers",36,13,23,0.361,9,9,4,14],["Charlotte Hornets",37,13,24,0.351,7,11,6,13],["Utah Jazz",36,12,24,0.333,8,11,4,13],["Brooklyn Nets",34,11,23,0.324,5,14,6,9],["Washington Wizards",36,10,26,0.278,6,12,4,14],["Sacramento Kings",37,8,29,0.216,5,13,3,16],["New Orleans Pelicans",39,8,31,0.205,6,17,2,14],["Indiana Pacers",37,6,31,0.162,5,15,1,16]]};

const COLS = ["date","home","away","mlHome","mlAway","spread","ou","points","homeWin","marketHomeProb","homeWinPct10","awayWinPct10","homeRest","awayRest"];
const games = DATA.games.map(row => Object.fromEntries(COLS.map((c,i) => [c, row[i]])));
const TCOLS = ["team","games","wins","losses","winPct","homeW","homeL","awayW","awayL"];
const teamsBase = DATA.teams.map(row => Object.fromEntries(TCOLS.map((c,i) => [c, row[i]])));

function fmtOdds(n) {
  if (n === null || n === undefined) return "\u2014";
  return n > 0 ? "+" + n : String(n);
}

function fmtPct(n) {
  if (n === null || n === undefined) return "\u2014";
  return Math.round(n * 1000) / 10 + "%";
}

function fmtDate(d) {
  const dt = new Date(d + "T00:00:00");
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default function LineSheet() {
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [sortKey, setSortKey] = useState("winPct");
  const [sortDir, setSortDir] = useState("desc");

  const teams = useMemo(() => {
    const arr = [...teamsBase];
    arr.sort((a, b) => {
      const v = sortDir === "desc" ? b[sortKey] - a[sortKey] : a[sortKey] - b[sortKey];
      return v;
    });
    return arr;
  }, [sortKey, sortDir]);

  const teamGames = useMemo(() => {
    if (!selectedTeam) return [];
    return games
      .filter(g => g.home === selectedTeam || g.away === selectedTeam)
      .slice()
      .reverse()
      .slice(0, 15);
  }, [selectedTeam]);

  const selectedStats = teamsBase.find(t => t.team === selectedTeam);

  const tickerGames = games.slice(-24);

  function toggleSort(key) {
    if (sortKey === key) {
      setSortDir(sortDir === "desc" ? "asc" : "desc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  }

  return (
    <div style={{
      background: "#12151B",
      color: "#ECE9E1",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      minHeight: "100vh",
      padding: 0,
    }}>
      <style>{`
        @keyframes ticker-scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .ticker-track {
          display: flex;
          width: max-content;
          animation: ticker-scroll 90s linear infinite;
        }
        .ticker-track:hover {
          animation-play-state: paused;
        }
        .ls-row:hover {
          background: #20242E !important;
          cursor: pointer;
        }
        .ls-th {
          cursor: pointer;
          user-select: none;
        }
        .ls-th:hover {
          color: #E3A73F;
        }
        ::-webkit-scrollbar { height: 6px; width: 6px; }
        ::-webkit-scrollbar-thumb { background: #2A2F3A; border-radius: 3px; }
      `}</style>

      {/* Ticker tape - signature element */}
      <div style={{
        borderBottom: "1px solid #2A2F3A",
        background: "#0D0F14",
        overflow: "hidden",
        padding: "9px 0",
      }}>
        <div className="ticker-track">
          {[...tickerGames, ...tickerGames].map((g, i) => (
            <div key={i} style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "0 20px",
              borderRight: "1px solid #22262F",
              whiteSpace: "nowrap",
              fontFamily: "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",
              fontSize: 12.5,
            }}>
              <span style={{ color: "#6B7180" }}>{fmtDate(g.date)}</span>
              <span style={{ color: "#ECE9E1" }}>{g.home.split(" ").pop()}</span>
              <span style={{ color: g.mlHome < 0 ? "#4FAE86" : "#E2665A", fontWeight: 600 }}>
                {fmtOdds(g.mlHome)}
              </span>
              <span style={{ color: "#454B58" }}>vs</span>
              <span style={{ color: "#ECE9E1" }}>{g.away.split(" ").pop()}</span>
              <span style={{ color: g.mlAway < 0 ? "#4FAE86" : "#E2665A", fontWeight: 600 }}>
                {fmtOdds(g.mlAway)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Header */}
      <div style={{ padding: "28px 24px 20px", borderBottom: "1px solid #2A2F3A" }}>
        <div style={{
          fontSize: 26,
          fontWeight: 800,
          letterSpacing: "0.02em",
          textTransform: "uppercase",
        }}>
          The Line Sheet
        </div>
        <div style={{ fontSize: 13.5, color: "#8B90A0", marginTop: 4 }}>
          NBA season data terminal \u2014 records, lines, and history. No predictions, no picks.
        </div>
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "minmax(0, 380px) minmax(0, 1fr)",
        gap: 0,
      }}>
        {/* Standings table */}
        <div style={{ borderRight: "1px solid #2A2F3A", padding: "20px" }}>
          <div style={{
            fontSize: 11,
            color: "#6B7180",
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            marginBottom: 12,
            fontWeight: 600,
          }}>
            2025\u201326 Standings ({teamsBase.length} teams)
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: "1px solid #2A2F3A" }}>
                <th style={{ textAlign: "left", padding: "6px 4px", color: "#8B90A0", fontWeight: 500 }}>Team</th>
                <th
                  className="ls-th"
                  onClick={() => toggleSort("games")}
                  style={{ textAlign: "right", padding: "6px 4px", color: "#8B90A0", fontWeight: 500, fontFamily: "ui-monospace, monospace" }}
                >GP</th>
                <th
                  className="ls-th"
                  onClick={() => toggleSort("winPct")}
                  style={{ textAlign: "right", padding: "6px 4px", color: "#8B90A0", fontWeight: 500, fontFamily: "ui-monospace, monospace" }}
                >W%</th>
              </tr>
            </thead>
            <tbody>
              {teams.map(t => (
                <tr
                  key={t.team}
                  className="ls-row"
                  onClick={() => setSelectedTeam(t.team)}
                  style={{
                    borderBottom: "1px solid #1B1F27",
                    background: selectedTeam === t.team ? "#20242E" : "transparent",
                  }}
                >
                  <td style={{ padding: "7px 4px", color: selectedTeam === t.team ? "#E3A73F" : "#ECE9E1" }}>
                    {t.team}
                  </td>
                  <td style={{
                    padding: "7px 4px",
                    textAlign: "right",
                    fontFamily: "ui-monospace, monospace",
                    color: "#8B90A0",
                    fontVariantNumeric: "tabular-nums",
                  }}>
                    {t.wins}-{t.losses}
                  </td>
                  <td style={{
                    padding: "7px 4px",
                    textAlign: "right",
                    fontFamily: "ui-monospace, monospace",
                    fontWeight: 600,
                    fontVariantNumeric: "tabular-nums",
                  }}>
                    {fmtPct(t.winPct)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Detail panel */}
        <div style={{ padding: "20px 24px" }}>
          {!selectedTeam && (
            <div style={{ color: "#6B7180", fontSize: 14, paddingTop: 40, textAlign: "center" }}>
              Select a team from the standings to view record splits and recent line history.
            </div>
          )}

          {selectedTeam && selectedStats && (
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 16, letterSpacing: "0.01em" }}>
                {selectedTeam}
              </div>

              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(4, 1fr)",
                gap: 10,
                marginBottom: 22,
              }}>
                {[
                  { label: "Record", value: `${selectedStats.wins}-${selectedStats.losses}` },
                  { label: "Win %", value: fmtPct(selectedStats.winPct) },
                  { label: "Home", value: `${selectedStats.homeW}-${selectedStats.homeL}` },
                  { label: "Away", value: `${selectedStats.awayW}-${selectedStats.awayL}` },
                ].map(card => (
                  <div key={card.label} style={{
                    background: "#1B1F27",
                    borderRadius: 6,
                    padding: "10px 12px",
                  }}>
                    <div style={{ fontSize: 10.5, color: "#6B7180", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 4 }}>
                      {card.label}
                    </div>
                    <div style={{
                      fontSize: 17,
                      fontWeight: 700,
                      fontFamily: "ui-monospace, monospace",
                      fontVariantNumeric: "tabular-nums",
                    }}>
                      {card.value}
                    </div>
                  </div>
                ))}
              </div>

              <div style={{
                fontSize: 11,
                color: "#6B7180",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                marginBottom: 10,
                fontWeight: 600,
              }}>
                Recent games
              </div>

              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, minWidth: 520 }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid #2A2F3A" }}>
                      <th style={{ textAlign: "left", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>Date</th>
                      <th style={{ textAlign: "left", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>Matchup</th>
                      <th style={{ textAlign: "right", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>Line</th>
                      <th style={{ textAlign: "right", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>O/U</th>
                      <th style={{ textAlign: "right", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>Score</th>
                      <th style={{ textAlign: "right", padding: "6px 8px", color: "#8B90A0", fontWeight: 500 }}>Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teamGames.map((g, i) => {
                      const isHome = g.home === selectedTeam;
                      const opp = isHome ? g.away : g.home;
                      const won = isHome ? g.homeWin === 1 : g.homeWin === 0;
                      const ml = isHome ? g.mlHome : g.mlAway;
                      return (
                        <tr key={i} style={{ borderBottom: "1px solid #1B1F27" }}>
                          <td style={{ padding: "7px 8px", color: "#8B90A0", fontFamily: "ui-monospace, monospace" }}>
                            {fmtDate(g.date)}
                          </td>
                          <td style={{ padding: "7px 8px" }}>
                            {isHome ? "vs" : "@"} {opp}
                          </td>
                          <td style={{
                            padding: "7px 8px",
                            textAlign: "right",
                            fontFamily: "ui-monospace, monospace",
                            fontVariantNumeric: "tabular-nums",
                            color: ml < 0 ? "#4FAE86" : "#E2665A",
                          }}>
                            {fmtOdds(ml)}
                          </td>
                          <td style={{
                            padding: "7px 8px",
                            textAlign: "right",
                            fontFamily: "ui-monospace, monospace",
                            color: "#8B90A0",
                            fontVariantNumeric: "tabular-nums",
                          }}>
                            {g.ou}
                          </td>
                          <td style={{
                            padding: "7px 8px",
                            textAlign: "right",
                            fontFamily: "ui-monospace, monospace",
                            color: "#8B90A0",
                            fontVariantNumeric: "tabular-nums",
                          }}>
                            {g.points}
                          </td>
                          <td style={{
                            padding: "7px 8px",
                            textAlign: "right",
                            fontWeight: 700,
                            color: won ? "#4FAE86" : "#E2665A",
                          }}>
                            {won ? "W" : "L"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={{
        padding: "16px 24px",
        borderTop: "1px solid #2A2F3A",
        fontSize: 11.5,
        color: "#4E5462",
      }}>
        Data: {games.length} games, 2025\u201326 season. Moneylines shown are closing consensus prices. No predictions or betting recommendations are made by this tool.
      </div>
    </div>
  );
}
